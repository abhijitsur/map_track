package com.example.dell.my_tracker;

import android.app.ActionBar;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageView toolbar_search;
    TextView toolbar_title;
    EditText toolbar_et_search;
    static int search_flag;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        search_flag=0;
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
       // final android.support.v7.app.ActionBar ab=getSupportActionBar();
        //ab.setDisplayShowTitleEnabled(false);
        // To initialize the Collapsing Toolbar  and
        // Set the Title of it

        CollapsingToolbarLayout collapsingToolbar =
                (CollapsingToolbarLayout) findViewById(R.id.toolbar_layout);
        collapsingToolbar.setTitle("Current Location");

        toolbar_et_search= (EditText) findViewById(R.id.toolbar_et_search);
        /*toolbar_et_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,"Searching...",Toast.LENGTH_LONG).show();
            }
        });*/
        toolbar_title= (TextView) findViewById(R.id.toolbar_title);
        toolbar_search= (ImageView) findViewById(R.id.toolbar_srch);
        toolbar_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(search_flag==0) {
                    toolbar_title.setVisibility(View.INVISIBLE);
                    toolbar_et_search.setVisibility(View.VISIBLE);
                    search_flag=1;
                }
                else{
                    toolbar_title.setVisibility(View.VISIBLE);
                    toolbar_et_search.setVisibility(View.INVISIBLE);
                    Toast.makeText(MainActivity.this,"Searching...",Toast.LENGTH_LONG).show();
                    search_flag=0;
                }


            }
        });

    }
}
